# esp32-http-fota
update firmware for esp32/esp8266 via http. It means ESP using http to download firmware and flashing firmware to it.

The example using libraries that are available on iotsharing.com. They are: 

http://www.iotsharing.com/2017/05/how-to-use-mqtt-to-build-smart-home-arduino-esp32.html

http://www.iotsharing.com/2017/05/how-to-update-firmware-ota-for-batch-esp32.html

http://www.iotsharing.com/2017/05/how-to-build-system-to-update-price-tag.html

File fotacontrol.py is used to test example 2. It used paho mqtt https://pypi.python.org/pypi/paho-mqtt/1.1.
